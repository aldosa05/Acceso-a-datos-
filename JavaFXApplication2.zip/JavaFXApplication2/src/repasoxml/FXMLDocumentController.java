/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package repasoxml;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;

/**
 *
 * @author DAM2
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField idTextInput;
    @FXML
    private TextField NombreTextinput;
    @FXML
    private TextField EquipoTextInput;
    @FXML
    private TextField AnyoTextInput;
    @FXML
    private TextField PosicionTextInput;
    @FXML
    private Button PrevioButton;
    @FXML
    private Button SiguienteButton;
    
    Integer position;
    
    ApoyoXML datos = new ApoyoXML();
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        position = 0;
         try {
            datos.LeerXML("datos.xml");
            
            FutbolistaPOJO FutbolistaInicial = new FutbolistaPOJO();
            FutbolistaInicial=datos.Read(0);
            idTextInput.setText(String.valueOf(FutbolistaInicial.getID()));
            NombreTextinput.setText(FutbolistaInicial.getNombre());
            EquipoTextInput.setText(FutbolistaInicial.getEquipo());
            AnyoTextInput.setText(String.valueOf(FutbolistaInicial.getAnyo()));
            PosicionTextInput.setText(FutbolistaInicial.getPosicion());
            
        } catch (SAXException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            datos.EscribirXML("hola.xml");
        } catch (TransformerException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }    
    
    private void PrevioButton(ActionEvent event) {
        position--;
    }
    
    private void SiguienteButton(ActionEvent event) {
        position++;
    }
}

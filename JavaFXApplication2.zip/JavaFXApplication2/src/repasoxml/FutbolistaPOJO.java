/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repasoxml;

/**
 *
 * @author DAM2
 */
public class FutbolistaPOJO {
    
    int ID;
    String Nombre;
    String Equipo;
    int Anyo;
    String Posicion;
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public String getEquipo() {
        return Equipo;
    }

    public void setEquipo(String Equipo) {
        this.Equipo = Equipo;
    }
    
    public int getAnyo() {
        return Anyo;
    }

    public void setAnyo(int Anyo) {
        this.Anyo = Anyo;
    }
    
    public String getPosicion() {
        return Posicion;
    }

    public void setPosicion(String Posicion) {
        this.Posicion = Posicion;
    }
    
}
